# Changelog

## 0.2.1

- The RUBIS teaser stays 5.5 s instead of 3.2 s (too fast to read on a phone). The CSS animation
  length now derives from `RUBIS_TEASER_MS`.
- Keep the RUBIS strip gold under browser-forced dark mode. Samsung Internet's dark mode turned the CSS gold
  brown and the dark-blue text white, and ignores `color-scheme: only light` (still declared, for browsers that
  honour it). The gold is now an embedded 0.5 kB PNG (`scripts/rubis-strip-png.mjs`), which it leaves alone, and
  the strip text is white with a dark-blue shadow, which read well with and without forced dark (phone tests).
- Release helper: Prepare type-checks the apps by default (`-AppCheck TypeCheck|Build|None`), reports
  how a failed step ended (e.g. interrupted, crashed), and accepts a version bump committed by hand.

## 0.2.0

- Show the customer's RUBIS in a solid Innopay-gold strip above the drawer handle (team choice "C2"):
  bold dark-blue figure + "RUBIS", ruby gem, two decimals rounded down, shown even at 0
  (`rubisBalance`; no strip while unknown or on a spoke without RUBIS).
- Add the "Spend RUBIS first" setting as the first drawer row, checked by default, light-blue tick box
  (`spendRubisFirst` + `onSpendRubisFirstChange`; the host stores it per device).
- Add the ruby & mango "earn RUBIS" teaser: above the wallet for holders at 0 RUBIS (`rubisEarnable`,
  `rubisTeaser`, `onRubisTeaserEnd`), and the standalone `RubisTeaser` for guests. About 3 s, never takes
  a tap, a plain fade under reduced motion.
- Export `formatRubis`, `shouldShowRubisTeaser` and `RUBIS_TEASER_MS`, so every spoke applies the same rules.
- New strings in FR/EN/LB/RO/DE.

## 0.1.4

- Restore the 💰 reopen button while keeping the Innopay logo on the wallet card.
- Narrow the card from 230px to 196px and place its title in a full-width, one-line top strip.
- Use the euro symbol in the preview balance instead of the ISO currency code.
- Make the rendered preview respond to close, reopen and Expand/Collapse clicks.

## 0.1.3

- Narrow the card and support a read-only public balance without a Delete action.
- Place Innohatch's vendor wallet on the till and its customer wallet on order checkout.
- Explain when the Innopay hub cannot be reached during account recovery.

## 0.1.2

- Give the Innopay logo two more pixels of space from the drag grip.
- Add Innohatch as a sixth local archive consumer.

## 0.1.1

- Slim the Expand/Collapse strip from 28px to 18px, with a 24px hit area.
- Add an embossed gradient, highlighted curved crest and pressed feedback.
- Center the amount and account name on the card using balanced side columns.
- Bundle the original Innopay gold-and-blue favicon for the card and reopen button, with no external image request.
- Show filled ▼ for Expand and ▲ for Collapse.
- Follow each host app’s current language for the title, actions, confirmation and reopen label; remove fixed hub titles.

## 0.1.0

- Extract shared compact MiniWallet, localized expandable actions and reopen button.
- Preserve per-app formatting, colors, pulse behavior and removal callbacks through adapters.
- Include scoped styles for ordinary pages and Shadow DOM, viewport-aware dragging and reduced-motion support.
- Clean up pending long presses when hidden/unmounted; close gestures invoke callbacks once.
- Distribute immutable npm archives with consumer integrity checks and full unit-suite verification.
