# @innopay/ui

Shared React MiniWallet UI for the Innopay hub and spokes. This directory is its own local Git repository, alongside the app repositories. The compact wallet is shared by the existing apps; version 0.1.4 keeps the embossed footer, centers the balance/account, shows the Innopay logo on the card, and uses 💰 to reopen a minimized wallet.

## Ownership

Edit the card, localized labels, expandable action panel, confirmation, wallet dragging and pulse animation in `src/` here. React and React DOM are peer dependencies, supporting React 18.3.1 and 19. There are no runtime dependencies on Next.js, Tailwind, Hive or application aliases.

The host owns balance fetching/formatting, pulse state, keys, storage, import/recovery and payments. `onForget` is a synchronous callback invoked after account-specific confirmation; each existing adapter calls its app's `forgetLocalWallet`. A thrown callback error is shown in the panel. No wallet credentials enter this package.

The original `innopay/public/favicon-32x32.png` is copied into `src/assets/innopay-32.png` and embedded as a data URI, so every host uses the same mark without depending on its own public folder. Run `node scripts/sync-logo.mjs` if replacing the asset.

Pass the app’s active language to both `MiniWallet` and `WalletReopenButton`. This follows the app’s default and its language selector; the package does not guess from the browser or read language storage. Millewee/Croque-Bedaine use their i18n state, the hub uses its selected language, Zenbar uses `lang`, and the current French-only Indies menu passes `fr`. A `title` override should be translated by the host; omit it to use the shared translation.

Styles are scoped and rendered inside the component, so the widget also works inside Zenbar's ShadowRoot. No separate CSS import or Tailwind content scan is needed. Reduced-motion preferences disable pulse motion while retaining its status color.

## Install in a new app

Copy the released archive into the app's `vendor/` folder, then run from that app:

```powershell
npm install --save-exact ./vendor/innopay-ui-0.1.4.tgz
```

Commit the archive, `package.json` and `package-lock.json` together. A fresh checkout or Vercel install needs only that app repository. It does not need this sibling source repository or registry credentials.

The archive exports TypeScript/TSX source. The app's normal build handles compilation. Next.js consumers must merge this into `next.config.ts`:

```ts
transpilePackages: ['@innopay/ui'],
```

Vite and Zenbar's esbuild widget already accept TSX imports. Vitest tests should import the installed package through the adapter, rather than aliasing the sibling source; that checks the actual archive used for deployment. If the test runner externalizes the package, add `test.server.deps.inline: ['@innopay/ui']` to its configuration.

## App adapter

```tsx
'use client';
import { MiniWallet } from '@innopay/ui';
import { forgetLocalWallet } from '@/lib/innopay/forget-wallet';

export function CustomerWallet() {
  return <MiniWallet accountName="alice" balanceLabel="12,50 €"
    accountUrl="https://wallet.innopay.lu/user" visible
    onClose={() => { /* set app visibility false */ }}
    onForget={() => forgetLocalWallet()} language="fr" />;
}
```

Required props: `accountName`, `balanceLabel`, `accountUrl`, `visible`, `onClose`. Pass `onForget` when the app has verified that this browser holds that account's keys. Omit it for a read-only public balance; the Expand/Delete controls are then absent.

Optional props: `language` (FR/EN/LB/RO/DE; default FR, unknown languages use EN), `title`, `cached`, `pulseState`, `onPulseReset`, `colors` (`idle`, `waiting`, `confirmed`, `problem` CSS backgrounds), `pulseOpacity`, `pulseScale`, `initialPosition`, `bottomInset`, `zIndex`, `fontFamily`, `balanceFontFamily`. Exported types document defaults and details. Pulse states remain `none`, `blue`, `green`, `green-slow`, `green-solid`, `red`.

`WalletReopenButton` takes `visible`, `onClick`, optional `language`, `label`, and `style`. Visibility is controlled by the app.

## Current consumers

| App | Adapter | App-specific behavior |
| --- | --- | --- |
| Millewee | `components/innopay/SharedMiniWallet.tsx` | EUR, environment-aware hub URL |
| Croque-Bedaine | `src/components/innopay/SharedMiniWallet.tsx` | €, React 18, Vite |
| Indies | `components/ui/SharedMiniWallet.tsx` | €, darker pulse colors |
| Innopay hub | `app/components/SharedMiniWallet.tsx` | €, local `/user` link |
| Zenbar | `widget/SharedMiniWallet.tsx` | lei, RO/EN, navy theme, Shadow DOM |
| Innohatch | `app/components/VendorTillWallet.tsx`, `app/components/CustomerMiniWallet.tsx` | EUR, vendor till public balance and customer order checkout |

Innohatch displays the vendor account's public balance on the till and the customer's saved wallet on order checkout. The till offers Delete only when its saved wallet matches the vendor account.

Original app `MiniWallet.tsx`, `WalletActions.tsx` and their tests are retained for user verification; production imports now use the adapters. Do not edit the retained copies for new features. After verifying the shared UI in app builds, the user can remove unused originals and their redundant tests. Generic app `Draggable.tsx` files still serve banners and other controls.

## Release helper (run it yourself)

The PowerShell helper stages one version across the library and all six app repositories. Run it from `innopay-ui` after changing the component and bumping `package.json`/`package-lock.json` to a new version:

```powershell
.\scripts\release-ui.ps1 -Mode Preview
.\scripts\release-ui.ps1 -Mode Prepare
```

`Prepare` runs `npm run release:local` (including the full unit suites), rebuilds Zenbar's committed widget, builds all six apps, verifies identical archives, and stages only release files. To defer the app builds, pass `-SkipAppBuilds`; Zenbar's widget is still rebuilt. Other app changes must be named explicitly, for example `-AdditionalFiles @('innohatch/app/components/CustomerMiniWallet.tsx')`. Reuse the same `-AdditionalFiles` in Commit mode. The helper stops if a repository already has staged changes or unrelated working changes.

Review the staged diffs in every repository, then run:

```powershell
.\scripts\release-ui.ps1 -Mode Commit
.\scripts\release-ui.ps1 -Mode Push
```

Commit makes seven separate **local** commits. Push sends all seven current branches to origin after checking that every repository is clean; rerun it if a network push fails. `Preview` is read-only. A previously released version cannot be repacked after its source changes; bump the version before preparing the next release. Finish any pending consumer-app changes from an earlier version before starting a new one.

For the current 0.1.4 rollout, use the reviewed wrapper instead of listing
the pending Millewee and Innohatch adapter paths yourself:

```powershell
.\scripts\release-014.ps1 -Mode Prepare
# Review the seven staged diffs printed above, then:
.\scripts\release-014.ps1 -Mode Finish
```

`Finish` commits and pushes the source repository and all six apps. If a push
fails, resolve it and rerun `.\scripts\release-ui.ps1 -Mode Push`; already
pushed branches will be no-ops. `Prepare` must be run in the user's terminal
because it executes the full test suites and production builds.

## Develop and release locally

From this directory:

```powershell
npm ci --ignore-scripts
npm test
# For a subsequent changed release (skip for the first 0.1.0 release):
npm version patch --no-git-tag-version
npm run release:local
```

`release:local` runs the full library suite, creates `releases/innopay-ui-<version>.tgz` with `npm pack --ignore-scripts`, copies identical archives into the six sibling apps, updates their dependencies/lockfiles, verifies archive and installed-source hashes, then runs every app's full `npm test` suite. It runs no builds, compilers, Git commits, network publishing or deployments. Installation uses `--ignore-scripts`, so the hub's Prisma postinstall is not triggered by this release step. Existing generated clients are left in place.

Every changed release needs a new version. The script refuses to overwrite a release or consumer archive with different contents. If installation/testing is interrupted, rerun the same command: unchanged archives are reused. Old version archives remain available until the user decides to clean them up. The source repository's ignored `releases/` folder is a local cache; the consumer repositories track their installed archives.

```powershell
npm run verify:consumers
```

When using `release:local` directly, run each app's production build in its own terminal and review the UI before committing the source and consumer files. The PowerShell `Prepare` mode runs these builds and rebuilds Zenbar's widget for you. Publishing to a registry can replace archive distribution later without changing component imports.
