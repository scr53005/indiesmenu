'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';

export type Position = { x: number; y: number };
interface Props {
  children: React.ReactNode;
  initialPosition?: Position;
  bottomInset?: number;
  className?: string;
  style?: React.CSSProperties;
}

/** Wallet-only wrapper. Other app banners keep their own positioning behaviour. */
export default function WalletDraggable({ children, initialPosition, bottomInset = 40, className, style }: Props) {
  // Identical server/client initial markup; choose the viewport-relative default after mount.
  const [position, setPosition] = useState(initialPosition ?? { x: 16, y: 40 });
  const [dragging, setDragging] = useState(false);
  const element = useRef<HTMLDivElement>(null);
  const offset = useRef({ x: 0, y: 0 });
  const initial = useRef(initialPosition);
  const initialized = useRef(false);
  const constrain = useCallback((next: Position): Position => {
    const rect = element.current?.getBoundingClientRect();
    if (!rect) return next;
    return {
      x: Math.max(8, Math.min(next.x, window.innerWidth - rect.width - 8)),
      y: Math.max(8, Math.min(next.y, window.innerHeight - rect.height - bottomInset)),
    };
  }, [bottomInset]);

  useEffect(() => {
    if (!initialized.current && !initial.current) {
      const cardWidth = element.current?.getBoundingClientRect().width ?? 0;
      setPosition(constrain({ x: window.innerWidth - cardWidth - 16, y: window.innerHeight - 170 }));
    }
    initialized.current = true;
  }, [constrain]);
  useEffect(() => {
    const fit = () => setPosition(previous => {
      const next = constrain(previous);
      return next.x === previous.x && next.y === previous.y ? previous : next;
    });
    fit();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(fit);
    if (element.current) observer?.observe(element.current);
    window.addEventListener('resize', fit);
    return () => { observer?.disconnect(); window.removeEventListener('resize', fit); };
  }, [constrain]);

  const start = (x: number, y: number) => {
    offset.current = { x: x - position.x, y: y - position.y };
    setDragging(true);
  };
  useEffect(() => {
    if (!dragging) return;
    const move = (event: MouseEvent) => setPosition(constrain({ x: event.clientX - offset.current.x, y: event.clientY - offset.current.y }));
    const touch = (event: TouchEvent) => {
      if (event.touches[0]) setPosition(constrain({ x: event.touches[0].clientX - offset.current.x, y: event.touches[0].clientY - offset.current.y }));
    };
    const end = () => setDragging(false);
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', end);
    document.addEventListener('touchmove', touch);
    document.addEventListener('touchend', end);
    document.addEventListener('touchcancel', end);
    return () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', end);
      document.removeEventListener('touchmove', touch);
      document.removeEventListener('touchend', end);
      document.removeEventListener('touchcancel', end);
    };
  }, [dragging, constrain]);

  return <div ref={element} className={className} style={{ ...style, position: 'fixed',
    left: position.x, top: position.y, cursor: dragging ? 'grabbing' : 'grab', touchAction: 'none', userSelect: 'none' }}
    onMouseDown={event => { if (event.button === 0) start(event.clientX, event.clientY); }}
    onTouchStart={event => { const touch = event.touches[0]; if (touch) start(touch.clientX, touch.clientY); }}>
    {children}
  </div>;
}
