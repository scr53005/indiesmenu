const copy = {
  en: {
    title: "Your Innopay wallet", close: "Close", reopen: "Show wallet",
    expand: 'Expand', collapse: 'Collapse', remove: 'Delete this wallet',
    recovery: '(you can always re-import it using your email or the saved keys)',
    confirm: 'Remove @{account} from this browser? The account and its funds remain available. You can re-import it using your email or saved keys.',
    error: 'The wallet could not be fully removed. Please try again.',
    spendFirst: 'Spend RUBIS first', spendHint: 'Untick to save them up',
    teaserHolder: 'Spend here to earn RUBIS!', teaserGuest: 'Order with an Innopay wallet and earn RUBIS!',
  },
  fr: {
    title: "Votre portefeuille Innopay", close: "Fermer", reopen: "Voir portefeuille",
    expand: 'Développer', collapse: 'Réduire', remove: 'Effacer ce portemonnaie',
    recovery: '(vous pourrez toujours le re-importer en utilisant votre email ou les clés sauvegardées)',
    confirm: 'Effacer @{account} de ce navigateur ? Le compte et ses fonds restent disponibles. Vous pourrez le réimporter avec votre email ou vos clés sauvegardées.',
    error: 'Le portemonnaie n’a pas pu être entièrement effacé. Veuillez réessayer.',
    spendFirst: 'Dépenser les RUBIS d’abord', spendHint: 'Décochez pour les accumuler',
    teaserHolder: 'Dépensez ici, gagnez des RUBIS !', teaserGuest: 'Commandez avec un portefeuille Innopay et gagnez des RUBIS !',
  },
  lb: {
    title: "Ären Innopay Portmonni", close: "Zoumaachen", reopen: "Portmonni weisen",
    expand: 'Ausklappen', collapse: 'Zesummeklappen', remove: 'Dëse Portmonni läschen',
    recovery: '(Dir kënnt en ëmmer nees mat Ärer E-Mail oder de gespäicherte Schlësselen importéieren)',
    confirm: '@{account} aus dësem Browser läschen? De Kont a säi Guthaben bleiwen disponibel. Dir kënnt en nees mat Ärer E-Mail oder de gespäicherte Schlësselen importéieren.',
    error: 'De Portmonni konnt net komplett geläscht ginn. Probéiert w.e.g. nach eng Kéier.',
    spendFirst: 'RUBIS als éischt ausginn', spendHint: 'Ofhaken fir se ze spueren',
    teaserHolder: 'Hei bezuelen, RUBIS verdéngen!', teaserGuest: 'Bestellt mat engem Innopay Portmonni a verdéngt RUBIS!',
  },
  ro: {
    title: "Portofelul tău Innopay", close: "Închide", reopen: "Arată portofelul",
    expand: 'Extinde', collapse: 'Restrânge', remove: 'Șterge acest portofel',
    recovery: '(îl poți reimporta oricând folosind adresa de email sau cheile salvate)',
    confirm: 'Ștergi @{account} din acest browser? Contul și fondurile rămân disponibile. Îl poți reimporta folosind adresa de email sau cheile salvate.',
    error: 'Portofelul nu a putut fi șters complet. Încearcă din nou.',
    spendFirst: 'Folosește întâi RUBIS', spendHint: 'Debifează ca să le economisești',
    teaserHolder: 'Plătește aici și câștigă RUBIS!', teaserGuest: 'Comandă cu un portofel Innopay și câștigă RUBIS!',
  },
  de: {
    title: "Deine Innopay Wallet", close: "Schließen", reopen: "Wallet anzeigen",
    expand: 'Erweitern', collapse: 'Einklappen', remove: 'Diese Wallet löschen',
    recovery: '(du kannst sie jederzeit mit deiner E-Mail oder den gespeicherten Schlüsseln erneut importieren)',
    confirm: '@{account} aus diesem Browser entfernen? Das Konto und sein Guthaben bleiben verfügbar. Du kannst es mit deiner E-Mail oder gespeicherten Schlüsseln erneut importieren.',
    error: 'Die Wallet konnte nicht vollständig entfernt werden. Bitte erneut versuchen.',
    spendFirst: 'RUBIS zuerst ausgeben', spendHint: 'Abwählen, um sie zu sammeln',
    teaserHolder: 'Hier bezahlen, RUBIS sammeln!', teaserGuest: 'Mit einer Innopay Wallet bestellen und RUBIS sammeln!',
  },
};

export function walletLabels(language: string) {
  return copy[language as keyof typeof copy] ?? copy.en;
}
