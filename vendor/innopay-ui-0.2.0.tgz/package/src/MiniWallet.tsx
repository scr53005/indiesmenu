'use client';

import React, { useCallback, useEffect, useRef } from 'react';
import WalletActions from './WalletActions';
import InnopayLogo from './InnopayLogo';
import WalletStyles from './WalletStyles';
import WalletDraggable, { type Position } from './WalletDraggable';
import { walletLabels } from './messages';
import RubisIcon from './RubisIcon';
import { TeaserPill, useTeaserPlayback } from './RubisTeaser';
import { displayableRubis, formatRubis } from './rubis';

export type PulseState = 'none' | 'blue' | 'green' | 'green-slow' | 'green-solid' | 'red';
export type WalletColors = { idle: string; waiting: string; confirmed: string; problem: string };
const defaultColors: WalletColors = {
  idle: 'linear-gradient(to right, #2563eb, #1d4ed8)',
  waiting: 'linear-gradient(to right, #3b82f6, #2563eb)',
  confirmed: 'linear-gradient(to right, #22c55e, #16a34a)',
  problem: 'linear-gradient(to right, #ef4444, #dc2626)',
};

export interface MiniWalletProps {
  accountName: string;
  /** Formatting and currency belong to the app, e.g. "12,50 €" or "12,50 lei". */
  balanceLabel: string;
  accountUrl: string;
  visible: boolean;
  onClose: () => void;
  /** Called only after the account-specific confirmation. The UI never handles keys. */
  onForget?: () => void;
  /** Pass the hosting app's active language, including changes made by its language selector. */
  language?: string;
  title?: string;
  cached?: boolean;
  pulseState?: PulseState;
  onPulseReset?: () => void;
  colors?: Partial<WalletColors>;
  pulseOpacity?: number;
  pulseScale?: number;
  initialPosition?: Position;
  bottomInset?: number;
  zIndex?: number;
  fontFamily?: string;
  balanceFontFamily?: string;
  /**
   * The customer's RUBIS, shown in the gold strip even at 0 (formatted here, the same on every spoke).
   * Leave undefined/null while unknown or on a spoke without RUBIS: no strip is drawn.
   */
  rubisBalance?: number | null;
  /** True only where the spoke gives RUBIS (it has a rubis_rate): gates the teaser. */
  rubisEarnable?: boolean;
  /** The host's go-ahead to play the "earn RUBIS" teaser once (see shouldShowRubisTeaser). */
  rubisTeaser?: boolean;
  onRubisTeaserEnd?: () => void;
  /** "Spend RUBIS first" drawer row; shown only when the host handles the change. Default checked. */
  spendRubisFirst?: boolean;
  onSpendRubisFirstChange?: (value: boolean) => void;
}

/** Presentational wallet: no storage, HTTP requests, account recovery or payment logic. */
export function MiniWallet({
  accountName, balanceLabel, accountUrl, visible, onClose, onForget,
  language = 'fr', title, cached = false, pulseState = 'none', onPulseReset,
  colors, pulseOpacity = .7, pulseScale = 1.03, initialPosition, bottomInset = 40,
  zIndex = 9998, fontFamily, balanceFontFamily,
  rubisBalance, rubisEarnable = false, rubisTeaser = false, onRubisTeaserEnd,
  spendRubisFirst = true, onSpendRubisFirstChange,
}: MiniWalletProps) {
  const rubis = displayableRubis(rubisBalance);
  // The package re-checks the rule, so a host can't show the teaser to someone who already has RUBIS.
  const teaserPlaying = useTeaserPlayback(rubisTeaser && rubisEarnable && rubis === 0 && visible, onRubisTeaserEnd);
  const lastTap = useRef<number | null>(null);
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const endPress = useCallback(() => {
    if (pressTimer.current !== null) clearTimeout(pressTimer.current);
    pressTimer.current = null;
  }, []);
  useEffect(() => {
    lastTap.current = null;
    endPress();
    return endPress;
  }, [visible, accountName, pulseState, endPress]);

  const tap = () => {
    if (pulseState === 'none' || !onPulseReset) return;
    const now = Date.now();
    if (lastTap.current !== null && now - lastTap.current < 400) {
      onPulseReset();
      lastTap.current = null;
    } else lastTap.current = now;
  };
  const startPress = () => {
    endPress();
    if (pulseState !== 'none' && onPulseReset) {
      pressTimer.current = setTimeout(() => { pressTimer.current = null; onPulseReset(); }, 1000);
    }
  };
  const stop = (event: React.SyntheticEvent) => event.stopPropagation();
  const close = (event: React.MouseEvent) => {
    event.stopPropagation();
    endPress();
    if (pulseState !== 'none') onPulseReset?.();
    onClose();
  };
  if (!visible) return null;

  const t = walletLabels(language);
  const palette = { ...defaultColors, ...colors };
  const background = pulseState === 'red' ? palette.problem : pulseState.startsWith('green')
    ? palette.confirmed : pulseState === 'blue' ? palette.waiting : palette.idle;
  const animated = pulseState !== 'none' && pulseState !== 'green-solid';
  const motionStyle = {
    '--innopay-pulse-opacity': pulseOpacity,
    '--innopay-pulse-scale': pulseScale,
  } as React.CSSProperties;

  return (
    <WalletDraggable initialPosition={initialPosition} bottomInset={bottomInset}
      className={`innopay-miniwallet${onForget ? "" : " mw-read-only"}`} style={{
        ...motionStyle, zIndex, background, fontFamily,
        animation: animated ? `innopay-wallet-pulse ${pulseState === 'green-slow' ? '4s' : '2s'} ease-in-out infinite` : undefined,
      }}>
      <WalletStyles />
      {teaserPlaying && <div className="innopay-rubis-holder-anchor"><TeaserPill text={t.teaserHolder} centered={false} /></div>}
      <div className="mw-header" onClick={tap} onMouseDown={startPress} onMouseUp={endPress}
        onMouseLeave={endPress} onTouchStart={startPress} onTouchEnd={endPress} onTouchCancel={endPress}>
        <div className="mw-title">{title ?? t.title}</div>
        <div className="mw-leading">
          <svg className="mw-grip" aria-hidden="true" width="7" height="16" viewBox="0 0 7 16" fill="currentColor">
            <circle cx="1" cy="4" r="1" /><circle cx="6" cy="4" r="1" />
            <circle cx="1" cy="8" r="1" /><circle cx="6" cy="8" r="1" />
            <circle cx="1" cy="12" r="1" /><circle cx="6" cy="12" r="1" />
          </svg>
          <InnopayLogo size={24} />
        </div>
        <div className="mw-info">
          <div className="mw-balance-row">
            <div>
              <p className="mw-amount" style={{ fontFamily: balanceFontFamily, fontStyle: cached ? 'italic' : undefined, color: cached ? '#bfdbfe' : undefined }}>{balanceLabel}</p>
              <a href={accountUrl} target="_blank" rel="noopener noreferrer" className="mw-account"
                onClick={stop} onMouseDown={stop} onTouchStart={stop}>{accountName}</a>
            </div>
          </div>
        </div>
        <button type="button" onClick={close} onMouseDown={stop} onTouchStart={stop} className="mw-close" aria-label={t.close}>
          <svg aria-hidden="true" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      {rubis !== null && (
        <div className="mw-rubis-strip">
          <RubisIcon className="mw-rubis-ico" />
          <span className="mw-rubis-num">{formatRubis(rubis, language)}</span>
          <span className="mw-rubis-unit">RUBIS</span>
        </div>
      )}
      {onForget && <WalletActions key={accountName} accountName={accountName} language={language} onForget={onForget}
        spendRubisFirst={spendRubisFirst} onSpendRubisFirstChange={onSpendRubisFirstChange} />}
    </WalletDraggable>
  );
}

export interface WalletReopenButtonProps {
  onClick: () => void;
  visible: boolean;
  /** Pass the hosting app's active language, including changes made by its language selector. */
  language?: string;
  label?: string;
  style?: React.CSSProperties;
}

export function WalletReopenButton({ onClick, visible, language = 'fr', label, style }: WalletReopenButtonProps) {
  if (!visible) return null;
  return <><WalletStyles /><button type="button" className="innopay-wallet-reopen" onClick={onClick}
    aria-label={label ?? walletLabels(language).reopen} style={style}><span aria-hidden="true">💰</span></button></>;
}
