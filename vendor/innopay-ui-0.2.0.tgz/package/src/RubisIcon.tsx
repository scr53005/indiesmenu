import React, { useId } from 'react';

/**
 * The RUBIS gem, drawn inline from innopay/public/images/rubis.svg so it needs no image request
 * and works in Shadow DOM. Gradient ids are made unique per instance: two wallets on a page
 * (or a wallet and a teaser) must not share them.
 */
export default function RubisIcon({ className }: { className?: string }) {
  const id = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const table = `rb-table-${id}`, heart = `rb-heart-${id}`;
  return (
    <svg className={className} viewBox="0 0 64 64" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={table} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff8f9c" /><stop offset="1" stopColor="#e8233d" />
        </linearGradient>
        <linearGradient id={heart} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e01e37" /><stop offset="1" stopColor="#7a0c16" />
        </linearGradient>
      </defs>
      <g transform="translate(32 33) rotate(35) scale(.86) translate(-32 -34)">
        <path d="M4 22 L16 8 L24 22 Z" fill="#ff5a6e" />
        <path d="M16 8 L32 8 L24 22 Z" fill="#ffb3bc" />
        <path d="M24 22 L32 8 L40 22 Z" fill={`url(#${table})`} />
        <path d="M32 8 L48 8 L40 22 Z" fill="#ff7486" />
        <path d="M40 22 L48 8 L60 22 Z" fill="#d3132c" />
        <path d="M4 22 L24 22 L32 60 Z" fill="#c4122a" />
        <path d="M24 22 L40 22 L32 60 Z" fill={`url(#${heart})`} />
        <path d="M40 22 L60 22 L32 60 Z" fill="#8e0d1e" />
        <path d="M24 22 L28.5 22 L32 60 Z" fill="#ff6b7d" opacity=".55" />
        <path d="M16 8 L32 8 M4 22 H60 M16 8 L24 22 L32 8 L40 22 L48 8 M24 22 L32 60 L40 22" fill="none"
          stroke="#fff" strokeOpacity=".35" strokeWidth=".9" strokeLinejoin="round" />
        <path d="M18.5 10 L29 10 L24 18.5 Z" fill="#fff" opacity=".55" />
        <path d="M10 22 L22 22 L29 48 Z" fill="#fff" opacity=".12" />
        <path d="M16 8 H48 L60 22 L32 60 L4 22 Z" fill="none" stroke="#5c0a12" strokeWidth="1.8" strokeLinejoin="round" />
      </g>
    </svg>
  );
}
