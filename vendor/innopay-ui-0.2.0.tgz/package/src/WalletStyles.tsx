'use client';
import React from 'react';

// Scoped styles travel with the component, including into a widget ShadowRoot.
export default function WalletStyles() {
  return <style>{`
        .innopay-miniwallet {
          box-sizing: border-box; padding: 8px 10px 0; border-radius: 12px;
          border: 1px solid rgba(255,255,255,.14); color: #fff;
          box-shadow: 0 4px 16px rgba(15,23,42,.18); width: 196px; min-width: 196px; max-width: 196px;
        }
        .innopay-miniwallet.mw-read-only { padding-bottom: 8px; }
        .innopay-miniwallet .mw-header { display: grid; grid-template-columns: 37px minmax(0, 1fr) 26px; align-items: center; column-gap: 4px; row-gap: 0; }
        .innopay-miniwallet .mw-leading { display: flex; align-items: center; gap: 5px; }
        .innopay-miniwallet .mw-grip { flex-shrink: 0; width: 7px; opacity: .4; }
        .innopay-miniwallet .mw-info { min-width: 0; text-align: center; }
        .innopay-miniwallet .mw-title { grid-column: 1 / -1; min-width: 0; width: calc(100% + 20px);
          margin: -8px -10px 5px; padding: 4px 5px 3px; border-radius: 11px 11px 0 0;
          background: linear-gradient(180deg, rgba(255,255,255,.15), rgba(0,0,0,.08));
          box-shadow: inset 0 -1px 0 rgba(255,255,255,.13); text-align: center;
          font-size: 11px; line-height: 14px; opacity: .9; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .innopay-miniwallet .mw-balance-row { min-width: 0; }
        .innopay-miniwallet .mw-logo { display: block; flex-shrink: 0; object-fit: contain; pointer-events: none; filter: drop-shadow(0 1px 1px rgba(0,0,0,.22)); }
        .innopay-miniwallet .mw-amount { display: block; font-size: 18px; font-weight: 650; line-height: 21px; margin: 0; font-variant-numeric: tabular-nums; }
        .innopay-miniwallet .mw-account { display: block; font-size: 11px; line-height: 14px; color: inherit; opacity: .75; text-decoration: none; }
        .innopay-miniwallet .mw-account:hover { opacity: 1; text-decoration: underline; }
        .innopay-miniwallet .mw-close { justify-self: end; display: grid; place-items: center; flex-shrink: 0; width: 26px; height: 26px; padding: 4px; border: 0; border-radius: 6px; background: transparent; color: inherit; opacity: .7; cursor: pointer; }
        .innopay-miniwallet .mw-close:hover { opacity: 1; background: rgba(255,255,255,.1); }
        .innopay-miniwallet .mw-close svg { width: 16px; height: 16px; }
        .innopay-wallet-actions { margin: 7px -10px 0; cursor: default; }
        .innopay-wallet-actions button { font-family: inherit; cursor: pointer; color: inherit; }
        .innopay-wallet-actions button:focus-visible { outline: 2px solid #fff; outline-offset: -3px; }
        .innopay-wallet-panel { padding: 5px 10px 6px; background: rgba(0,0,0,.09); border-top: 1px solid rgba(255,255,255,.12); max-height: 40vh; overflow-y: auto; }
        .innopay-wallet-delete { display: flex; align-items: flex-start; gap: 7px; width: 100%; padding: 5px 0; border: 0; background: transparent; text-align: left; white-space: normal; line-height: 1.35; border-radius: 4px; }
        .innopay-wallet-delete:hover { background: rgba(255,255,255,.06); }
        .innopay-wallet-delete strong { display: block; font-size: 12px; font-weight: 600; }
        .innopay-wallet-delete small { display: block; font-size: 11px; margin-top: 2px; opacity: .78; }
        .innopay-wallet-toggle {
          position: relative; display: flex; align-items: center; justify-content: center; gap: 4px;
          width: 100%; height: 18px; padding: 0; border: 0; border-radius: 0 0 11px 11px;
          background: linear-gradient(180deg, rgba(255,255,255,.26) 0%, rgba(255,255,255,.10) 38%, rgba(0,0,0,.08) 72%, rgba(0,0,0,.18) 100%);
          box-shadow: inset 0 1px 0 rgba(255,255,255,.22), inset 0 -1px 1px rgba(0,0,0,.16);
          font-size: 10px; line-height: 12px; font-weight: 500; letter-spacing: .02em;
          text-shadow: 0 1px 1px rgba(0,0,0,.32);
        }
        .innopay-wallet-toggle .mw-disclosure-triangle { font-size: 9px; line-height: 1; }
        /* A 24px hit area keeps the visibly thin strip easy to tap. */
        .innopay-wallet-toggle::after { content: ''; position: absolute; inset: -3px 0; }
        .innopay-wallet-toggle:hover { background: linear-gradient(180deg, rgba(255,255,255,.34) 0%, rgba(255,255,255,.16) 38%, rgba(0,0,0,.04) 72%, rgba(0,0,0,.14) 100%); }
        .innopay-wallet-toggle:active { box-shadow: inset 0 1px 3px rgba(0,0,0,.28); }
        .innopay-wallet-toggle .mw-crest { color: rgba(255,255,255,.26); }
        .innopay-wallet-toggle:hover .mw-crest { color: rgba(255,255,255,.34); }
      
        .innopay-miniwallet { font-family: system-ui, sans-serif; }
        .innopay-miniwallet *, .innopay-wallet-reopen { box-sizing: border-box; }
        .innopay-miniwallet svg { display: block; }
        .innopay-miniwallet .mw-balance-row > div { min-width: 0; }
        .innopay-miniwallet .mw-account { font-family: ui-monospace, monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .innopay-miniwallet [hidden] { display: none !important; }
        .innopay-miniwallet .mw-close:focus-visible, .innopay-miniwallet .mw-account:focus-visible,
        .innopay-wallet-reopen:focus-visible { outline: 2px solid #fff; outline-offset: -3px; }
        .innopay-wallet-reopen { position: fixed; bottom: 16px; right: 16px; z-index: 9998;
          display: grid; place-items: center; width: 56px; height: 56px; border: 0; padding: 12px;
          border-radius: 50%; background: #2563eb; color: white; font-size: 24px; line-height: 1;
          cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,.2); }
        .innopay-wallet-reopen:hover { filter: brightness(.92); }
        /* RUBIS strip (team choice "C2", 2026-11-04): solid Innopay gold, from the logo's golds without its
           bright yellow. Opaque because a translucent gold over the blue card turns greenish. Bold dark blue
           text: thin navy on gold was hard to read at this size. */
        .innopay-miniwallet .mw-rubis-strip { margin: 7px -10px 0; display: flex; justify-content: center; align-items: center; gap: 3px;
          height: 20px; font-size: 11.5px; font-weight: 700; color: #0f2d86; white-space: nowrap; font-variant-numeric: tabular-nums;
          background: linear-gradient(180deg, #f0b632 0%, #d99e12 55%, #b07d0b 100%);
          box-shadow: inset 0 1px 0 rgba(255,255,255,.6), inset 0 -1px 0 rgba(120,80,0,.45); text-shadow: 0 1px 0 rgba(255,255,255,.45); }
        .innopay-miniwallet .mw-rubis-ico { width: 14px; height: 14px; flex-shrink: 0; filter: drop-shadow(0 0 1px rgba(255,255,255,.6)); }
        .innopay-miniwallet .mw-rubis-unit { font-size: .78em; letter-spacing: .05em; opacity: .85; }
        .innopay-miniwallet.mw-read-only .mw-rubis-strip { margin-bottom: -8px; border-radius: 0 0 11px 11px; }
        .innopay-miniwallet .mw-rubis-strip + .innopay-wallet-actions { margin-top: 0; }

        /* "Spend RUBIS first", first row of the drawer. Light blue when ticked: white with a red tick was too loud. */
        .mw-pref { position: relative; display: flex; align-items: flex-start; gap: 7px; padding: 5px 0 7px; border-bottom: 1px solid rgba(255,255,255,.12); cursor: pointer; line-height: 1.35; }
        .mw-pref input { position: absolute; opacity: 0; width: 1px; height: 1px; margin: 0; }
        .mw-pref .mw-check { flex-shrink: 0; width: 15px; height: 15px; margin-top: 1px; border-radius: 4px; border: 1.5px solid rgba(255,255,255,.75); display: grid; place-items: center; transition: background .15s; }
        .mw-pref .mw-check svg { width: 11px; height: 11px; opacity: 0; }
        .mw-pref input:checked + .mw-check { background: #bfdbfe; border-color: #bfdbfe; }
        .mw-pref input:checked + .mw-check svg { opacity: 1; }
        .mw-pref input:focus-visible + .mw-check { outline: 2px solid #fff; outline-offset: 2px; }
        .mw-pref strong { display: block; font-size: 12px; font-weight: 600; }
        .mw-pref small { display: block; font-size: 11px; margin-top: 2px; opacity: .78; }
        .mw-pref .mw-gem { display: inline-block; width: 12px; height: 12px; vertical-align: -1px; margin-right: 3px; }

        /* "Earn RUBIS" teaser, ruby & mango (team choice). Never takes a tap. */
        .innopay-rubis-holder-anchor { position: absolute; right: 0; bottom: calc(100% + 12px); pointer-events: none; }
        .innopay-rubis-guest-anchor { position: fixed; left: 0; right: 0; display: flex; justify-content: center; padding: 0 14px; pointer-events: none; }
        .innopay-rubis-teaser { position: relative; display: inline-flex; align-items: center; gap: 8px; width: max-content; max-width: 260px;
          padding: 8px 14px 8px 8px; border-radius: 999px; color: #fff; isolation: isolate; pointer-events: none;
          background: linear-gradient(135deg, #e01e37 0%, #fb7185 55%, #fbbf24 100%);
          font: 700 13.5px/1.25 system-ui, sans-serif; letter-spacing: .005em; text-align: left; text-shadow: 0 1px 1px rgba(122,12,22,.35);
          box-shadow: 0 10px 24px -8px rgba(225,29,72,.55), inset 0 1px 0 rgba(255,255,255,.45), 0 0 0 1px rgba(255,255,255,.35);
          animation: innopay-teaser-life 3.2s cubic-bezier(.2,.8,.2,1) forwards; }
        .innopay-rubis-teaser .rt-badge { flex-shrink: 0; display: grid; place-items: center; width: 28px; height: 28px; border-radius: 50%; background: rgba(255,255,255,.92); box-shadow: 0 1px 3px rgba(122,12,22,.3); }
        .innopay-rubis-teaser .rt-badge svg { width: 20px; height: 20px; animation: innopay-teaser-wobble 1.6s .2s ease-in-out; }
        .innopay-rubis-teaser .rt-shine { position: absolute; inset: 0; border-radius: inherit; overflow: hidden; z-index: -1; }
        .innopay-rubis-teaser .rt-shine::after { content: ''; position: absolute; inset: 0; transform: translateX(-120%);
          background: linear-gradient(110deg, transparent 30%, rgba(255,255,255,.6) 48%, transparent 66%); animation: innopay-teaser-shine 1.2s .3s ease-out; }
        .innopay-rubis-teaser .rt-tail { position: absolute; bottom: -5px; right: 30px; width: 11px; height: 11px; background: #fbbf24; transform: rotate(45deg); border-radius: 2px; z-index: -2; }
        .innopay-rubis-teaser.is-centered .rt-tail { right: auto; left: calc(50% - 5px); background: #fb7185; }
        .innopay-rubis-teaser .rt-spark { position: absolute; color: #fff; opacity: 0; filter: drop-shadow(0 0 3px rgba(251,191,36,.9)); animation: innopay-teaser-twinkle 1.3s ease-in-out infinite; }
        .innopay-rubis-teaser .rt-spark svg { width: 100%; height: 100%; }
        @keyframes innopay-teaser-life { 0% { opacity: 0; transform: translateY(12px) scale(.7); } 9% { opacity: 1; transform: translateY(-3px) scale(1.05); } 15% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-3px); } 84% { opacity: 1; transform: translateY(0); } 100% { opacity: 0; transform: translateY(-16px) scale(.96); } }
        @keyframes innopay-teaser-twinkle { 0%, 100% { opacity: 0; transform: scale(.2) rotate(0deg); } 45% { opacity: 1; transform: scale(1) rotate(45deg); } }
        @keyframes innopay-teaser-shine { to { transform: translateX(120%); } }
        @keyframes innopay-teaser-wobble { 0%, 100% { transform: rotate(0); } 25% { transform: rotate(-14deg) scale(1.1); } 55% { transform: rotate(10deg); } }
        @keyframes innopay-teaser-fade { 0% { opacity: 0; } 8%, 88% { opacity: 1; } 100% { opacity: 0; } }
        @media (prefers-reduced-motion: reduce) {
          .innopay-rubis-teaser { animation: innopay-teaser-fade 3.2s linear forwards; }
          .innopay-rubis-teaser .rt-spark { display: none; }
          .innopay-rubis-teaser .rt-shine::after, .innopay-rubis-teaser .rt-badge svg { animation: none; }
        }
        @keyframes innopay-wallet-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: var(--innopay-pulse-opacity, .7); transform: scale(var(--innopay-pulse-scale, 1.03)); }
        }
        @media (prefers-reduced-motion: reduce) { .innopay-miniwallet { animation: none !important; } }
`}</style>;
}
