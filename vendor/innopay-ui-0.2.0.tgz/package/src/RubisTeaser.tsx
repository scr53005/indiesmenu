'use client';

import React, { useEffect, useRef, useState } from 'react';
import RubisIcon from './RubisIcon';
import WalletStyles from './WalletStyles';
import { walletLabels } from './messages';
import { RUBIS_TEASER_MS } from './rubis';

// [position, delay, size]: seven sparkles, staggered so two or three are lit at any moment.
const SPARKS: [React.CSSProperties, string, number][] = [
  [{ top: -10, left: '5%' }, '0s', 17], [{ top: -13, left: '55%' }, '.35s', 19], [{ top: -9, left: '82%' }, '1.05s', 14],
  [{ top: '26%', right: -11 }, '.2s', 17], [{ bottom: -11, left: '86%' }, '.7s', 16],
  [{ bottom: -12, left: '30%' }, '.95s', 18], [{ top: '28%', left: -11 }, '.55s', 15],
];

/** Plays once each time `show` turns true, then hides itself and calls `onEnd`. Internal to the package. */
export function useTeaserPlayback(show: boolean, onEnd?: () => void): boolean {
  const [playing, setPlaying] = useState(false);
  const end = useRef(onEnd);
  useEffect(() => { end.current = onEnd; }, [onEnd]);
  useEffect(() => {
    if (!show) { setPlaying(false); return; }
    setPlaying(true);
    const timer = setTimeout(() => { setPlaying(false); end.current?.(); }, RUBIS_TEASER_MS);
    return () => clearTimeout(timer);
  }, [show]);
  return playing;
}

/** The pill itself; the tail points down at the wallet (holder) or the cart button (guest). */
export function TeaserPill({ text, centered }: { text: string; centered: boolean }) {
  return (
    <div className={`innopay-rubis-teaser${centered ? ' is-centered' : ''}`} role="status">
      <span className="rt-shine" /><span className="rt-tail" />
      <span className="rt-badge"><RubisIcon /></span>
      <span>{text}</span>
      {SPARKS.map(([position, delay, size], index) => (
        <span key={index} className="rt-spark" aria-hidden="true"
          style={{ ...position, width: size, height: size, animationDelay: delay }}>
          <svg viewBox="0 0 24 24"><path d="M12 0 C13 8 16 11 24 12 C16 13 13 16 12 24 C11 16 8 13 0 12 C8 11 11 8 12 0 Z" fill="currentColor" /></svg>
        </span>
      ))}
    </div>
  );
}

export interface RubisTeaserProps {
  /** Turn true to play it once; use `shouldShowRubisTeaser` to decide. */
  show: boolean;
  /** Called when it has finished; the place to remember "shown this session". */
  onEnd?: () => void;
  /** Pass the hosting app's active language. */
  language?: string;
  /** Override the translated guest line. */
  text?: string;
  /** Distance from the bottom of the screen, to clear the spoke's cart button. */
  bottom?: number;
  zIndex?: number;
}

/**
 * The guest teaser: someone who scanned a table QR has no wallet on screen, so this one stands
 * alone, centred above the cart button. It invites ordering WITH a wallet, because guest checkout
 * earns nothing. Wallet holders get theirs from MiniWallet (`rubisTeaser`).
 */
export function RubisTeaser({ show, onEnd, language = 'fr', text, bottom = 88, zIndex = 9997 }: RubisTeaserProps) {
  const playing = useTeaserPlayback(show, onEnd);
  if (!playing) return null;
  return (
    <>
      <WalletStyles />
      <div className="innopay-rubis-guest-anchor" style={{ bottom, zIndex }}>
        <TeaserPill text={text ?? walletLabels(language).teaserGuest} centered />
      </div>
    </>
  );
}
