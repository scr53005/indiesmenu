// RUBIS display rules shared by every spoke (RUBIS-PLAN.md §5), so the wallet reads the same everywhere.

/**
 * Two decimals, rounded DOWN: the wallet must never show a cent the customer does not have.
 * Decimal comma except in English; thousands separated by a narrow no-break space
 * (a comma in English), which no language misreads as a decimal mark.
 */
export function formatRubis(amount: number, language = 'fr'): string {
  // + 1e-6 absorbs float noise (0.29 * 100 = 28.999…) without rounding a real fraction up.
  const cents = Math.floor(amount * 100 + 1e-6);
  const en = language === 'en';
  const whole = String(Math.floor(cents / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, en ? ',' : ' ');
  return `${whole}${en ? '.' : ','}${String(cents % 100).padStart(2, '0')}`;
}

/** A balance the wallet can show; anything else (not loaded, failed read) shows no strip. */
export function displayableRubis(balance: number | null | undefined): number | null {
  return typeof balance === 'number' && Number.isFinite(balance) && balance >= 0 ? balance : null;
}

/**
 * The host decides when the teaser plays. Only where the spoke gives RUBIS, only for a wallet that
 * is confirmed at 0 (a guest has no balance: pass `balance: 0`), never during a payment, once per session.
 */
export function shouldShowRubisTeaser({ earnable, balance, paying, shownThisSession }: {
  earnable: boolean; balance: number | null | undefined; paying: boolean; shownThisSession: boolean;
}): boolean {
  return earnable && displayableRubis(balance) === 0 && !paying && !shownThisSession;
}

/** Long enough to read the line once; the CSS animation is timed to the same value. */
export const RUBIS_TEASER_MS = 3200;
