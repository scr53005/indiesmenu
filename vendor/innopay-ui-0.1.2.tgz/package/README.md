# @innopay/ui

Shared React MiniWallet UI for the Innopay hub and spokes. This directory is its own local Git repository, alongside the app repositories. The compact wallet is shared by the existing apps; version 0.1.2 keeps a thinner embossed footer, centered balance/account, the Innopay logo, and filled disclosure triangles.

## Ownership

Edit the card, localized labels, expandable action panel, confirmation, wallet dragging and pulse animation in `src/` here. React and React DOM are peer dependencies, supporting React 18.3.1 and 19. There are no runtime dependencies on Next.js, Tailwind, Hive or application aliases.

The host owns balance fetching/formatting, pulse state, keys, storage, import/recovery and payments. `onForget` is a synchronous callback invoked after account-specific confirmation; each existing adapter calls its app's `forgetLocalWallet`. A thrown callback error is shown in the panel. No wallet credentials enter this package.

The original `innopay/public/favicon-32x32.png` is copied into `src/assets/innopay-32.png` and embedded as a data URI, so every host uses the same mark without depending on its own public folder. Run `node scripts/sync-logo.mjs` if replacing the asset.

Pass the app’s active language to both `MiniWallet` and `WalletReopenButton`. This follows the app’s default and its language selector; the package does not guess from the browser or read language storage. Millewee/Croque-Bedaine use their i18n state, the hub uses its selected language, Zenbar uses `lang`, and the current French-only Indies menu passes `fr`. A `title` override should be translated by the host; omit it to use the shared translation.

Styles are scoped and rendered inside the component, so the widget also works inside Zenbar's ShadowRoot. No separate CSS import or Tailwind content scan is needed. Reduced-motion preferences disable pulse motion while retaining its status color.

## Install in a new app

Copy the released archive into the app's `vendor/` folder, then run from that app:

```powershell
npm install --save-exact ./vendor/innopay-ui-0.1.2.tgz
```

Commit the archive, `package.json` and `package-lock.json` together. A fresh checkout or Vercel install needs only that app repository. It does not need this sibling source repository or registry credentials.

The archive exports TypeScript/TSX source. The app's normal build handles compilation. Next.js consumers must merge this into `next.config.ts`:

```ts
transpilePackages: ['@innopay/ui'],
```

Vite and Zenbar's esbuild widget already accept TSX imports. Vitest tests should import the installed package through the adapter, rather than aliasing the sibling source; that checks the actual archive used for deployment. If the test runner externalizes the package, add `test.server.deps.inline: ['@innopay/ui']` to its configuration.

## App adapter

```tsx
'use client';
import { MiniWallet } from '@innopay/ui';
import { forgetLocalWallet } from '@/lib/innopay/forget-wallet';

export function CustomerWallet() {
  return <MiniWallet accountName="alice" balanceLabel="12.50 EUR"
    accountUrl="https://wallet.innopay.lu/user" visible
    onClose={() => { /* set app visibility false */ }}
    onForget={() => forgetLocalWallet()} language="fr" />;
}
```

Required props: `accountName`, `balanceLabel`, `accountUrl`, `visible`, `onClose`, `onForget`.

Optional props: `language` (FR/EN/LB/RO/DE; default FR, unknown languages use EN), `title`, `cached`, `pulseState`, `onPulseReset`, `colors` (`idle`, `waiting`, `confirmed`, `problem` CSS backgrounds), `pulseOpacity`, `pulseScale`, `initialPosition`, `bottomInset`, `zIndex`, `fontFamily`, `balanceFontFamily`. Exported types document defaults and details. Pulse states remain `none`, `blue`, `green`, `green-slow`, `green-solid`, `red`.

`WalletReopenButton` takes `visible`, `onClick`, optional `language`, `label`, and `style`. Visibility is controlled by the app.

## Current consumers

| App | Adapter | App-specific behavior |
| --- | --- | --- |
| Millewee | `components/innopay/SharedMiniWallet.tsx` | EUR, environment-aware hub URL |
| Croque-Bedaine | `src/components/innopay/SharedMiniWallet.tsx` | €, React 18, Vite |
| Indies | `components/ui/SharedMiniWallet.tsx` | €, darker pulse colors |
| Innopay hub | `app/components/SharedMiniWallet.tsx` | €, local `/user` link |
| Zenbar | `widget/SharedMiniWallet.tsx` | lei, RO/EN, navy theme, Shadow DOM |
| Innohatch | `app/components/CustomerMiniWallet.tsx` | EUR, FR customer pages, keystore-owned removal |

Innohatch displays the shared MiniWallet on customer browse and checkout pages through `app/components/CustomerMiniWallet.tsx`.

Original app `MiniWallet.tsx`, `WalletActions.tsx` and their tests are retained for user verification; production imports now use the adapters. Do not edit the retained copies for new features. After verifying the shared UI in app builds, the user can remove unused originals and their redundant tests. Generic app `Draggable.tsx` files still serve banners and other controls.

## Develop and release locally

From this directory:

```powershell
npm ci --ignore-scripts
npm test
# For a subsequent changed release (skip for the first 0.1.0 release):
npm version patch --no-git-tag-version
npm run release:local
```

`release:local` runs the full library suite, creates `releases/innopay-ui-<version>.tgz` with `npm pack --ignore-scripts`, copies identical archives into the six sibling apps, updates their dependencies/lockfiles, verifies archive and installed-source hashes, then runs every app's full `npm test` suite. It runs no builds, compilers, Git commits, network publishing or deployments. Installation uses `--ignore-scripts`, so the hub's Prisma postinstall is not triggered by this release step. Existing generated clients are left in place.

Every changed release needs a new version. The script refuses to overwrite a release or consumer archive with different contents. If installation/testing is interrupted, rerun the same command: unchanged archives are reused. Old version archives remain available until the user decides to clean them up. The source repository's ignored `releases/` folder is a local cache; the consumer repositories track their installed archives.

```powershell
npm run verify:consumers
```

After release, run each app's production build in its own terminal and review the UI, then commit the source repository and each consumer's adapter/import/config, archive, manifest and lockfile changes. For Zenbar this includes rebuilding its widget. App build scripts may also run database migrations; use the normal intended environment. Publishing to a registry can replace archive distribution later without changing component imports.
