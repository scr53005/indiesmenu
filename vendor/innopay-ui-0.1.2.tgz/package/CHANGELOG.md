# Changelog

## 0.1.2

- Give the Innopay logo two more pixels of space from the drag grip.
- Add Innohatch as a sixth local archive consumer.

## 0.1.1

- Slim the Expand/Collapse strip from 28px to 18px, with a 24px hit area.
- Add an embossed gradient, highlighted curved crest and pressed feedback.
- Center the amount and account name on the card using balanced side columns.
- Bundle the original Innopay gold-and-blue favicon for the card and reopen button, with no external image request.
- Show filled ▼ for Expand and ▲ for Collapse.
- Follow each host app’s current language for the title, actions, confirmation and reopen label; remove fixed hub titles.

## 0.1.0

- Extract shared compact MiniWallet, localized expandable actions and reopen button.
- Preserve per-app formatting, colors, pulse behavior and removal callbacks through adapters.
- Include scoped styles for ordinary pages and Shadow DOM, viewport-aware dragging and reduced-motion support.
- Clean up pending long presses when hidden/unmounted; close gestures invoke callbacks once.
- Distribute immutable npm archives with consumer integrity checks and full unit-suite verification.
