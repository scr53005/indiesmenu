# Changelog

## 0.1.0

- Extract shared compact MiniWallet, localized expandable actions and reopen button.
- Preserve per-app formatting, colors, pulse behavior and removal callbacks through adapters.
- Include scoped styles for ordinary pages and Shadow DOM, viewport-aware dragging and reduced-motion support.
- Clean up pending long presses when hidden/unmounted; close gestures invoke callbacks once.
- Distribute immutable npm archives with consumer integrity checks and full unit-suite verification.
