'use client';

import React, { useCallback, useEffect, useRef } from 'react';
import WalletActions from './WalletActions';
import WalletStyles from './WalletStyles';
import WalletDraggable, { type Position } from './WalletDraggable';
import { walletLabels } from './messages';

export type PulseState = 'none' | 'blue' | 'green' | 'green-slow' | 'green-solid' | 'red';
export type WalletColors = { idle: string; waiting: string; confirmed: string; problem: string };
const defaultColors: WalletColors = {
  idle: 'linear-gradient(to right, #2563eb, #1d4ed8)',
  waiting: 'linear-gradient(to right, #3b82f6, #2563eb)',
  confirmed: 'linear-gradient(to right, #22c55e, #16a34a)',
  problem: 'linear-gradient(to right, #ef4444, #dc2626)',
};

export interface MiniWalletProps {
  accountName: string;
  /** Formatting and currency belong to the app, e.g. "12.50 EUR" or "12,50 lei". */
  balanceLabel: string;
  accountUrl: string;
  visible: boolean;
  onClose: () => void;
  /** Called only after the account-specific confirmation. The UI never handles keys. */
  onForget: () => void;
  language?: string;
  title?: string;
  cached?: boolean;
  pulseState?: PulseState;
  onPulseReset?: () => void;
  colors?: Partial<WalletColors>;
  pulseOpacity?: number;
  pulseScale?: number;
  initialPosition?: Position;
  bottomInset?: number;
  zIndex?: number;
  fontFamily?: string;
  balanceFontFamily?: string;
}

/** Presentational wallet: no storage, HTTP requests, account recovery or payment logic. */
export function MiniWallet({
  accountName, balanceLabel, accountUrl, visible, onClose, onForget,
  language = 'fr', title, cached = false, pulseState = 'none', onPulseReset,
  colors, pulseOpacity = .7, pulseScale = 1.03, initialPosition, bottomInset = 40,
  zIndex = 9998, fontFamily, balanceFontFamily,
}: MiniWalletProps) {
  const lastTap = useRef<number | null>(null);
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const endPress = useCallback(() => {
    if (pressTimer.current !== null) clearTimeout(pressTimer.current);
    pressTimer.current = null;
  }, []);
  useEffect(() => {
    lastTap.current = null;
    endPress();
    return endPress;
  }, [visible, accountName, pulseState, endPress]);

  const tap = () => {
    if (pulseState === 'none' || !onPulseReset) return;
    const now = Date.now();
    if (lastTap.current !== null && now - lastTap.current < 400) {
      onPulseReset();
      lastTap.current = null;
    } else lastTap.current = now;
  };
  const startPress = () => {
    endPress();
    if (pulseState !== 'none' && onPulseReset) {
      pressTimer.current = setTimeout(() => { pressTimer.current = null; onPulseReset(); }, 1000);
    }
  };
  const stop = (event: React.SyntheticEvent) => event.stopPropagation();
  const close = (event: React.MouseEvent) => {
    event.stopPropagation();
    endPress();
    if (pulseState !== 'none') onPulseReset?.();
    onClose();
  };
  if (!visible) return null;

  const t = walletLabels(language);
  const palette = { ...defaultColors, ...colors };
  const background = pulseState === 'red' ? palette.problem : pulseState.startsWith('green')
    ? palette.confirmed : pulseState === 'blue' ? palette.waiting : palette.idle;
  const animated = pulseState !== 'none' && pulseState !== 'green-solid';
  const motionStyle = {
    '--innopay-pulse-opacity': pulseOpacity,
    '--innopay-pulse-scale': pulseScale,
  } as React.CSSProperties;

  return (
    <WalletDraggable initialPosition={initialPosition} bottomInset={bottomInset}
      className="innopay-miniwallet" style={{
        ...motionStyle, zIndex, background, fontFamily,
        animation: animated ? `innopay-wallet-pulse ${pulseState === 'green-slow' ? '4s' : '2s'} ease-in-out infinite` : undefined,
      }}>
      <WalletStyles />
      <div className="mw-header" onClick={tap} onMouseDown={startPress} onMouseUp={endPress}
        onMouseLeave={endPress} onTouchStart={startPress} onTouchEnd={endPress} onTouchCancel={endPress}>
        <svg className="mw-grip" aria-hidden="true" width="7" height="16" viewBox="0 0 7 16" fill="currentColor">
          <circle cx="1" cy="4" r="1" /><circle cx="6" cy="4" r="1" />
          <circle cx="1" cy="8" r="1" /><circle cx="6" cy="8" r="1" />
          <circle cx="1" cy="12" r="1" /><circle cx="6" cy="12" r="1" />
        </svg>
        <div className="mw-info">
          <p className="mw-title">{title ?? t.title}</p>
          <div className="mw-balance-row">
            <svg className="mw-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M20 8V6a2 2 0 0 0-2-2H6a3 3 0 0 0 0 6h14v10H6a3 3 0 0 1-3-3V7m17 7h-4v3h4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div>
              <p className="mw-amount" style={{ fontFamily: balanceFontFamily, fontStyle: cached ? 'italic' : undefined, color: cached ? '#bfdbfe' : undefined }}>{balanceLabel}</p>
              <a href={accountUrl} target="_blank" rel="noopener noreferrer" className="mw-account"
                onClick={stop} onMouseDown={stop} onTouchStart={stop}>{accountName}</a>
            </div>
          </div>
        </div>
        <button type="button" onClick={close} onMouseDown={stop} onTouchStart={stop} className="mw-close" aria-label={t.close}>
          <svg aria-hidden="true" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      <WalletActions key={accountName} accountName={accountName} language={language} onForget={onForget} />
    </WalletDraggable>
  );
}

export interface WalletReopenButtonProps {
  onClick: () => void;
  visible: boolean;
  language?: string;
  label?: string;
  style?: React.CSSProperties;
}

export function WalletReopenButton({ onClick, visible, language = 'fr', label, style }: WalletReopenButtonProps) {
  if (!visible) return null;
  return <><WalletStyles /><button type="button" className="innopay-wallet-reopen" onClick={onClick}
    aria-label={label ?? walletLabels(language).reopen} style={style}><span aria-hidden="true">💰</span></button></>;
}
