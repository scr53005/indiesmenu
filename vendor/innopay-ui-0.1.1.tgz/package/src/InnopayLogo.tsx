import React from 'react';
import { innopayLogo } from './logo-data';

/** Embedded original favicon: works in each host's page and in Shadow DOM. */
export default function InnopayLogo({ size }: { size: number }) {
  return <img className="mw-logo" src={innopayLogo} width={size} height={size}
    alt="" aria-hidden="true" draggable={false} />;
}
