'use client';

import React, { useId, useState } from 'react';
import { walletLabels } from './messages';

/** Account removal is delegated to the host after confirmation. */
export default function WalletActions({ accountName, language = 'fr', onForget }: {
  accountName: string;
  language?: string;
  onForget: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [error, setError] = useState(false);
  const panelId = useId();
  const t = walletLabels(language);
  const stop = (event: React.SyntheticEvent) => event.stopPropagation();

  const forget = () => {
    if (!window.confirm(t.confirm.replace('{account}', accountName.replace(/^@/, '')))) return;
    try {
      setError(false);
      onForget();
    } catch {
      setError(true);
    }
  };

  return (
    <div className="innopay-wallet-actions" onMouseDown={stop} onTouchStart={stop} onPointerDown={stop} onClick={stop}>
      <div id={panelId} hidden={!expanded} className="innopay-wallet-panel">
        <button type="button" onClick={forget} className="innopay-wallet-delete">
          <svg aria-hidden="true" width="15" height="15" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.4"
            style={{ flexShrink: 0, marginTop: 1, opacity: .8 }}>
            <path d="M3 5h14M7 5V3h6v2M5 5l1 12h8l1-12M8 8v6m4-6v6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span><strong>{t.remove}</strong><small>{t.recovery}</small></span>
        </button>
        {error && <p role="alert" style={{ fontSize: 11, margin: '4px 0' }}>{t.error}</p>}
      </div>
      <button type="button" aria-expanded={expanded} aria-controls={panelId} className="innopay-wallet-toggle"
        onClick={() => setExpanded(value => !value)}>
        <svg className="mw-crest" aria-hidden="true" viewBox="0 0 280 5" preserveAspectRatio="none"
          style={{ position: 'absolute', left: 0, top: -4, width: '100%', height: 5, pointerEvents: 'none' }}>
          <path d="M0 5H116C128 5 128 1 140 1S152 5 164 5H280" fill="currentColor" stroke="rgba(255,255,255,.32)" strokeWidth=".7" />
        </svg>
        <span className="mw-toggle-label">{expanded ? t.collapse : t.expand}</span>
        <span className="mw-disclosure-triangle" aria-hidden="true">{expanded ? '▲' : '▼'}</span>
      </button>
    </div>
  );
}
