'use client';
import React from 'react';

// Scoped styles travel with the component, including into a widget ShadowRoot.
export default function WalletStyles() {
  return <style>{`
        .innopay-miniwallet {
          box-sizing: border-box; padding: 8px 10px 0; border-radius: 12px;
          border: 1px solid rgba(255,255,255,.14); color: #fff;
          box-shadow: 0 4px 16px rgba(15,23,42,.18); width: 250px; min-width: 220px; max-width: 280px;
        }
        .innopay-miniwallet .mw-header { display: grid; grid-template-columns: 32px minmax(0, 1fr) 32px; align-items: center; gap: 6px; }
        .innopay-miniwallet .mw-leading { display: flex; align-items: center; gap: 4px; }
        .innopay-miniwallet .mw-grip { flex-shrink: 0; width: 7px; opacity: .4; }
        .innopay-miniwallet .mw-info { min-width: 0; text-align: center; }
        .innopay-miniwallet .mw-title { display: block; font-size: 11px; line-height: 14px; margin: 0 0 3px; opacity: .75; }
        .innopay-miniwallet .mw-balance-row { min-width: 0; }
        .innopay-miniwallet .mw-logo, .innopay-wallet-reopen .mw-logo { display: block; flex-shrink: 0; object-fit: contain; pointer-events: none; filter: drop-shadow(0 1px 1px rgba(0,0,0,.22)); }
        .innopay-miniwallet .mw-amount { display: block; font-size: 18px; font-weight: 650; line-height: 21px; margin: 0; font-variant-numeric: tabular-nums; }
        .innopay-miniwallet .mw-account { display: block; font-size: 11px; line-height: 14px; color: inherit; opacity: .75; text-decoration: none; }
        .innopay-miniwallet .mw-account:hover { opacity: 1; text-decoration: underline; }
        .innopay-miniwallet .mw-close { justify-self: end; display: grid; place-items: center; flex-shrink: 0; width: 26px; height: 26px; padding: 4px; border: 0; border-radius: 6px; background: transparent; color: inherit; opacity: .7; cursor: pointer; }
        .innopay-miniwallet .mw-close:hover { opacity: 1; background: rgba(255,255,255,.1); }
        .innopay-miniwallet .mw-close svg { width: 16px; height: 16px; }
        .innopay-wallet-actions { margin: 7px -10px 0; cursor: default; }
        .innopay-wallet-actions button { font-family: inherit; cursor: pointer; color: inherit; }
        .innopay-wallet-actions button:focus-visible { outline: 2px solid #fff; outline-offset: -3px; }
        .innopay-wallet-panel { padding: 5px 10px 6px; background: rgba(0,0,0,.09); border-top: 1px solid rgba(255,255,255,.12); max-height: 40vh; overflow-y: auto; }
        .innopay-wallet-delete { display: flex; align-items: flex-start; gap: 7px; width: 100%; padding: 5px 0; border: 0; background: transparent; text-align: left; white-space: normal; line-height: 1.35; border-radius: 4px; }
        .innopay-wallet-delete:hover { background: rgba(255,255,255,.06); }
        .innopay-wallet-delete strong { display: block; font-size: 12px; font-weight: 600; }
        .innopay-wallet-delete small { display: block; font-size: 11px; margin-top: 2px; opacity: .78; }
        .innopay-wallet-toggle {
          position: relative; display: flex; align-items: center; justify-content: center; gap: 4px;
          width: 100%; height: 18px; padding: 0; border: 0; border-radius: 0 0 11px 11px;
          background: linear-gradient(180deg, rgba(255,255,255,.26) 0%, rgba(255,255,255,.10) 38%, rgba(0,0,0,.08) 72%, rgba(0,0,0,.18) 100%);
          box-shadow: inset 0 1px 0 rgba(255,255,255,.22), inset 0 -1px 1px rgba(0,0,0,.16);
          font-size: 10px; line-height: 12px; font-weight: 500; letter-spacing: .02em;
          text-shadow: 0 1px 1px rgba(0,0,0,.32);
        }
        .innopay-wallet-toggle .mw-disclosure-triangle { font-size: 9px; line-height: 1; }
        /* A 24px hit area keeps the visibly thin strip easy to tap. */
        .innopay-wallet-toggle::after { content: ''; position: absolute; inset: -3px 0; }
        .innopay-wallet-toggle:hover { background: linear-gradient(180deg, rgba(255,255,255,.34) 0%, rgba(255,255,255,.16) 38%, rgba(0,0,0,.04) 72%, rgba(0,0,0,.14) 100%); }
        .innopay-wallet-toggle:active { box-shadow: inset 0 1px 3px rgba(0,0,0,.28); }
        .innopay-wallet-toggle .mw-crest { color: rgba(255,255,255,.26); }
        .innopay-wallet-toggle:hover .mw-crest { color: rgba(255,255,255,.34); }
      
        .innopay-miniwallet { font-family: system-ui, sans-serif; }
        .innopay-miniwallet *, .innopay-wallet-reopen { box-sizing: border-box; }
        .innopay-miniwallet svg { display: block; }
        .innopay-miniwallet .mw-balance-row > div { min-width: 0; }
        .innopay-miniwallet .mw-account { font-family: ui-monospace, monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .innopay-miniwallet [hidden] { display: none !important; }
        .innopay-miniwallet .mw-close:focus-visible, .innopay-miniwallet .mw-account:focus-visible,
        .innopay-wallet-reopen:focus-visible { outline: 2px solid #fff; outline-offset: -3px; }
        .innopay-wallet-reopen { position: fixed; bottom: 16px; right: 16px; z-index: 9998;
          display: grid; place-items: center; width: 56px; height: 56px; border: 0; padding: 12px;
          border-radius: 50%; background: #2563eb; color: white; font-size: 24px; line-height: 1;
          cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,.2); }
        .innopay-wallet-reopen:hover { filter: brightness(.92); }
        @keyframes innopay-wallet-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: var(--innopay-pulse-opacity, .7); transform: scale(var(--innopay-pulse-scale, 1.03)); }
        }
        @media (prefers-reduced-motion: reduce) { .innopay-miniwallet { animation: none !important; } }
`}</style>;
}
